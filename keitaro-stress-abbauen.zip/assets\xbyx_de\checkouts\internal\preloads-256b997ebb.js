
    (function() {
      var cdnOrigin = "https://cdn.shopify.com";
      var scripts = ["/cdn/shopifycloud/checkout-web/assets/c1/polyfills.CgsWKOqO.js","/cdn/shopifycloud/checkout-web/assets/c1/app.BAfo4Jo_.js","/cdn/shopifycloud/checkout-web/assets/c1/vendor.ST0jZOux.js","/cdn/shopifycloud/checkout-web/assets/c1/browser.ghqTDstm.js","/cdn/shopifycloud/checkout-web/assets/c1/FullScreenBackground.Dhfmo3KY.js","/cdn/shopifycloud/checkout-web/assets/c1/object.SHxX1Pih.js","/cdn/shopifycloud/checkout-web/assets/c1/shop-discount-offer.CQZ5iWE8.js","/cdn/shopifycloud/checkout-web/assets/c1/alternativePaymentCurrency.B6NjF-Lz.js","/cdn/shopifycloud/checkout-web/assets/c1/proposal.BoGGjMrG.js","/cdn/shopifycloud/checkout-web/assets/c1/useHasOrdersFromMultipleShops.Dt1nZbGt.js","/cdn/shopifycloud/checkout-web/assets/c1/locale-de.D5PzFDpu.js","/cdn/shopifycloud/checkout-web/assets/c1/page-Information.CPgUcqt4.js","/cdn/shopifycloud/checkout-web/assets/c1/PaymentButtons.C0fYLATg.js","/cdn/shopifycloud/checkout-web/assets/c1/Page.C4n3xEgn.js","/cdn/shopifycloud/checkout-web/assets/c1/helpers.BkZ8lWeh.js","/cdn/shopifycloud/checkout-web/assets/c1/MarketsProDisclaimer.BA1pLSh3.js","/cdn/shopifycloud/checkout-web/assets/c1/RememberMeDescriptionText.Di_iD_np.js","/cdn/shopifycloud/checkout-web/assets/c1/ShopPayLogo.Dh7KZbmu.js","/cdn/shopifycloud/checkout-web/assets/c1/VaultedPayment.rXZaBDBn.js","/cdn/shopifycloud/checkout-web/assets/c1/ShippingGroupsSummaryLine.CTkY_BSr.js","/cdn/shopifycloud/checkout-web/assets/c1/StackedMerchandisePreview.CkzUeL8i.js","/cdn/shopifycloud/checkout-web/assets/c1/PickupPointCarrierLogo.D8EdtWvx.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks.DEbQBUxe.js","/cdn/shopifycloud/checkout-web/assets/c1/component-RuntimeExtension.HA7SSby9.js","/cdn/shopifycloud/checkout-web/assets/c1/AnnouncementRuntimeExtensions.Baovh5en.js","/cdn/shopifycloud/checkout-web/assets/c1/rendering-extension-targets.mzUpYEF1.js","/cdn/shopifycloud/checkout-web/assets/c1/v4.BKrj-4V8.js","/cdn/shopifycloud/checkout-web/assets/c1/shipping-options.SqPFEOnr.js","/cdn/shopifycloud/checkout-web/assets/c1/ExtensionsInner.Cr8IGL4h.js","/cdn/shopifycloud/checkout-web/assets/c1/useShopPayNewSignupLoginExperiment.CS7vA08e.js"];
      var styles = ["/cdn/shopifycloud/checkout-web/assets/c1/assets/app.au8IBghB.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/FullScreenBackground.B_iZlQze.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useHasOrdersFromMultipleShops.BXcLvY09.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Page.BYM12A8B.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/helpers.BhtheElV.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/RememberMeDescriptionText.BrcQzLuH.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/VaultedPayment.OxMVm7u-.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/PickupPointCarrierLogo.DuZuWHqZ.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/StackedMerchandisePreview.D6OuIVjc.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/RuntimeExtension.DWkDBM73.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/AnnouncementRuntimeExtensions.V0VYEO4K.css"];
      var fontPreconnectUrls = [];
      var fontPrefetchUrls = [];
      var imgPrefetchUrls = ["https://cdn.shopify.com/s/files/1/0262/3366/7644/files/XbyX_Logo_Subline_black_Kopie_9c081f53-239e-494e-91f7-431c45ee013c_x320.png?v=1614770704"];

      function preconnect(url, callback) {
        var link = document.createElement('link');
        link.rel = 'dns-prefetch preconnect';
        link.href = url;
        link.crossOrigin = '';
        link.onload = link.onerror = callback;
        document.head.appendChild(link);
      }

      function preconnectAssets() {
        var resources = [cdnOrigin].concat(fontPreconnectUrls);
        var index = 0;
        (function next() {
          var res = resources[index++];
          if (res) preconnect(res, next);
        })();
      }

      function prefetch(url, as, callback) {
        var link = document.createElement('link');
        if (link.relList.supports('prefetch')) {
          link.rel = 'prefetch';
          link.fetchPriority = 'low';
          link.as = as;
          if (as === 'font') link.type = 'font/woff2';
          link.href = url;
          link.crossOrigin = '';
          link.onload = link.onerror = callback;
          document.head.appendChild(link);
        } else {
          var xhr = new XMLHttpRequest();
          xhr.open('GET', url, true);
          xhr.onloadend = callback;
          xhr.send();
        }
      }

      function prefetchAssets() {
        var resources = [].concat(
          scripts.map(function(url) { return [url, 'script']; }),
          styles.map(function(url) { return [url, 'style']; }),
          fontPrefetchUrls.map(function(url) { return [url, 'font']; }),
          imgPrefetchUrls.map(function(url) { return [url, 'image']; })
        );
        var index = 0;
        function run() {
          var res = resources[index++];
          if (res) prefetch(res[0], res[1], next);
        }
        var next = (self.requestIdleCallback || setTimeout).bind(self, run);
        next();
      }

      function onLoaded() {
        try {
          if (parseFloat(navigator.connection.effectiveType) > 2 && !navigator.connection.saveData) {
            preconnectAssets();
            prefetchAssets();
          }
        } catch (e) {}
      }

      if (document.readyState === 'complete') {
        onLoaded();
      } else {
        addEventListener('load', onLoaded);
      }
    })();
  