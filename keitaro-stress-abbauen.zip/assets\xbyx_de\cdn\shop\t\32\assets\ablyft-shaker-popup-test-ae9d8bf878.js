/** Shopify CDN: Minification failed

Line 9:41 Transforming default arguments to the configured target environment ("es5") is not supported yet
Line 9:63 Transforming default arguments to the configured target environment ("es5") is not supported yet
Line 37:12 Expected ";" but found "{"

**/
(() => {
  function retryPool(callback, retryTime = 1e3, retryFrequency = 25) {
    
    if (retryTime <= 0)
    
    return;
    
    setTimeout(() => {
    
      retryPool(callback, retryTime - retryFrequency, retryFrequency);
    
    }, retryFrequency);
    
    callback();
  
  }
  
  var q = (a, b) => b ? a.querySelector(b) : document.querySelector(a);
  
  var info = {
  
    SITE: "xbx",
    
    ID: "71",
    
    VAR: "control"
  
  };
  
  var ID = ${info.SITE}-${[info.ID](http://info.ID "‌")}-${info.VAR};
  
  window.runningExperiments = window.runningExperiments || {};
  
  window.runningExperiments[ID] = {
  
    name: "Hide free shaker popup from PDP"
  
  };
  
  window.ablyft.getTools().domLoaded(() => {
  
    q("body").classList.add(ID);
    
    retryPool(() => {
    
      window.enable_shaker_popup = "false";
      
      document.cookie = "enable_shaker_popup=false;expires=0;path=/";
    
    });
  
  });

})();

